import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { TextInput, Button, Text, Provider as PaperProvider } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';

const App = () => {
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [errorMessage, setErrorMessage] = React.useState('');
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);

  React.useEffect(() => {
    verificarSessao();
  }, []);

  const verificarSessao = async () => {
    try {
      const savedUsername = await AsyncStorage.getItem('username');
      if (savedUsername) {
        setUsername(savedUsername);
        setIsLoggedIn(true);
      }
    } catch (error) {
      setErrorMessage('Error: ' + error);
    }
  };

  const fazerLogin = async () => {
    if (username === 'admin' && password === 'admin') {
      try {
        await AsyncStorage.setItem('username', username);
        setIsLoggedIn(true);
        setErrorMessage('');
      } catch (error) {
        setErrorMessage(`Failed to save session: ${error.message}`);
      }
    } else {
      setErrorMessage('Incorrect username or password. Please try again.');
    }
  };

  const fazerLogout = async () => {
    try {
      await AsyncStorage.removeItem('username');
      setIsLoggedIn(false);
    } catch (error) {
      setErrorMessage('Error: ' + error);
    }
  };

  return (
    <PaperProvider>
      <View style={styles.container}>
        <Image source={require('./assets/logo.jpg')} style={styles.logo} />
        {isLoggedIn ? (
          <View style={styles.loggedInContainer}>
            <Text>Welcome, {username}!</Text>
            <Button icon="logout" mode="contained" onPress={fazerLogout} style={styles.button}>
              Logout
            </Button>
          </View>
        ) : (
          <View style={styles.loginContainer}>
            <TextInput
              label="Username"
              value={username}
              onChangeText={setUsername}
              style={styles.input}
            />
            <TextInput
              label="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              style={styles.input}
            />
            <Button icon="login" mode="contained" onPress={fazerLogin} style={styles.button}>
              Login
            </Button>
            {errorMessage ? <Text style={styles.errorText}>{errorMessage}</Text> : null}
          </View>
        )}
      </View>
    </PaperProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: 150, 
    height: 100, 
    marginBottom: 20,
  },
  loginContainer: {
    width: '80%',
    maxWidth: 300, 
    padding: 20,
    backgroundColor: 'white', 
    borderRadius: 10,
    alignItems: 'center', 
  },
  input: {
    marginBottom: 10,
    width: '100%', 
    backgroundColor: '#d6dee2', 
    borderWidth: 2, 
    borderColor: 'black',
    height: 40,
  },
  button: {
    marginTop: 10,
    width: '100%', 
    backgroundColor: 'blue',
    height: 35,
  },
  loggedInContainer: {
    alignItems: 'center',
  },
  errorText: {
    color: 'red',
    marginTop: 10,
  },
});

export default App;
